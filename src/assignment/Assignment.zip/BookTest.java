package assignment;

public class BookTest {

	public static void main(String[] args) {
		Book[] edition = new Book[2];

		edition[0] = new Book("Java Programming", 350.55f);
		edition[1] = new Book("Let us c", 200.00f);

		System.out.println("----Book Details----");
		System.out.println();
		for (int i = 0; i < edition.length; i++) {
			System.out.println("Book name : " + edition[i].getBookTitle());
			System.out.println("Cost of Book : " + "Rs." + edition[i].getBookPrice());

			System.out.println("-----------------------");

		}

	}

}
